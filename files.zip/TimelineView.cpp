#include "TimelineView.h"
#include "Application.h"
#include <algorithm>
#include <sstream>
#include <iomanip>
#include <cmath>

void TimelineView::addTrack(std::shared_ptr<Track> track) {
    m_tracks.push_back(track);
    invalidate();
}

void TimelineView::removeTrack(size_t index) {
    if (index < m_tracks.size()) {
        m_tracks.erase(m_tracks.begin() + index);
        invalidate();
    }
}

void TimelineView::setPlayheadPosition(double seconds) {
    m_playheadPosition = std::max(0.0, seconds);
    invalidate();
}

void TimelineView::setPixelsPerSecond(double pps) {
    m_pixelsPerSecond = std::clamp(pps, 10.0, 1000.0);
    invalidate();
}

void TimelineView::setScrollX(double x) {
    m_scrollX = std::max(0.0, x);
    invalidate();
}

void TimelineView::setScrollY(int y) {
    m_scrollY = std::max(0, y);
    invalidate();
}

void TimelineView::onRender(ID2D1RenderTarget* rt) {
    // Clear background
    fillRect(0, 0, static_cast<float>(getWidth()), static_cast<float>(getHeight()), 
             DAWColors::Background);
    
    // Draw grid first (under everything)
    if (m_showGrid) {
        drawGrid(rt);
    }
    
    // Draw tracks
    drawTracks(rt);
    
    // Draw ruler at top
    drawRuler(rt);
    
    // Draw playhead on top
    drawPlayhead(rt);
    
    // Track header backgrounds (drawn last to cover grid)
    fillRect(0, 0, TRACK_HEADER_WIDTH, static_cast<float>(getHeight()), 
             DAWColors::TrackHeader);
    
    // Redraw track headers on top
    float y = RULER_HEIGHT - m_scrollY;
    for (auto& track : m_tracks) {
        if (y + track->getHeight() > RULER_HEIGHT && y < getHeight()) {
            drawTrackHeader(rt, *track, y, static_cast<float>(track->getHeight()));
        }
        y += track->getHeight();
    }
    
    // Corner box (top-left)
    fillRect(0, 0, TRACK_HEADER_WIDTH, RULER_HEIGHT, DAWColors::TrackHeader);
    drawRect(0, 0, TRACK_HEADER_WIDTH, RULER_HEIGHT, DAWColors::GridLine);
}

void TimelineView::drawRuler(ID2D1RenderTarget* rt) {
    float rulerY = 0;
    float contentX = static_cast<float>(TRACK_HEADER_WIDTH);
    float contentWidth = static_cast<float>(getWidth() - TRACK_HEADER_WIDTH);
    
    // Ruler background
    fillRect(contentX, rulerY, contentWidth, RULER_HEIGHT, DAWColors::Timeline);
    
    // Calculate time interval for markers based on zoom level
    double secondsPerPixel = 1.0 / m_pixelsPerSecond;
    double visibleSeconds = contentWidth * secondsPerPixel;
    
    // Choose appropriate interval
    double interval = 1.0;  // 1 second default
    if (visibleSeconds > 60) interval = 10.0;
    else if (visibleSeconds > 30) interval = 5.0;
    else if (visibleSeconds > 10) interval = 2.0;
    else if (visibleSeconds < 2) interval = 0.5;
    else if (visibleSeconds < 1) interval = 0.1;
    
    double startTime = m_scrollX - fmod(m_scrollX, interval);
    double endTime = m_scrollX + visibleSeconds + interval;
    
    for (double t = startTime; t <= endTime; t += interval) {
        int x = timeToPixel(t);
        if (x < TRACK_HEADER_WIDTH || x > getWidth()) continue;
        
        // Marker line
        bool isMajor = fmod(t, interval * 4) < 0.001;
        float lineHeight = isMajor ? RULER_HEIGHT * 0.6f : RULER_HEIGHT * 0.3f;
        
        drawLine(static_cast<float>(x), RULER_HEIGHT - lineHeight,
                 static_cast<float>(x), static_cast<float>(RULER_HEIGHT),
                 isMajor ? DAWColors::GridLineMajor : DAWColors::GridLine, 1.0f);
        
        // Time label for major markers
        if (isMajor || interval >= 1.0) {
            int mins = static_cast<int>(t) / 60;
            int secs = static_cast<int>(t) % 60;
            std::wostringstream ss;
            ss << mins << L":" << std::setfill(L'0') << std::setw(2) << secs;
            drawText(ss.str(), static_cast<float>(x + 4), 4, 
                     DAWColors::TimelineText, 60, 20);
        }
    }
    
    // Bottom border
    drawLine(contentX, RULER_HEIGHT, static_cast<float>(getWidth()), RULER_HEIGHT,
             DAWColors::GridLine, 1.0f);
}

void TimelineView::drawGrid(ID2D1RenderTarget* rt) {
    float contentX = static_cast<float>(TRACK_HEADER_WIDTH);
    float contentWidth = static_cast<float>(getWidth() - TRACK_HEADER_WIDTH);
    
    // Calculate beat interval
    double secondsPerBeat = 60.0 / m_bpm;
    double beatsPerBar = 4.0;
    double secondsPerBar = secondsPerBeat * beatsPerBar;
    
    // Choose grid resolution based on zoom
    double secondsPerPixel = 1.0 / m_pixelsPerSecond;
    double visibleSeconds = contentWidth * secondsPerPixel;
    
    double gridInterval = secondsPerBeat;
    if (visibleSeconds > 30) gridInterval = secondsPerBar;
    else if (visibleSeconds < 5) gridInterval = secondsPerBeat / 2;
    else if (visibleSeconds < 2) gridInterval = secondsPerBeat / 4;
    
    double startTime = m_scrollX - fmod(m_scrollX, gridInterval);
    double endTime = m_scrollX + visibleSeconds + gridInterval;
    
    for (double t = startTime; t <= endTime; t += gridInterval) {
        int x = timeToPixel(t);
        if (x < TRACK_HEADER_WIDTH || x > getWidth()) continue;
        
        // Check if this is a bar line
        bool isBarLine = fmod(t, secondsPerBar) < 0.001;
        
        drawLine(static_cast<float>(x), static_cast<float>(RULER_HEIGHT),
                 static_cast<float>(x), static_cast<float>(getHeight()),
                 isBarLine ? DAWColors::GridLineMajor : DAWColors::GridLine, 
                 isBarLine ? 1.0f : 0.5f);
    }
}

void TimelineView::drawTracks(ID2D1RenderTarget* rt) {
    float y = static_cast<float>(RULER_HEIGHT - m_scrollY);
    
    for (size_t i = 0; i < m_tracks.size(); ++i) {
        auto& track = m_tracks[i];
        float height = static_cast<float>(track->getHeight());
        
        if (y + height > RULER_HEIGHT && y < getHeight()) {
            // Track content area background
            float contentX = static_cast<float>(TRACK_HEADER_WIDTH);
            float contentWidth = static_cast<float>(getWidth() - TRACK_HEADER_WIDTH);
            
            // Alternate track colors
            Color bgColor = (i % 2 == 0) ? DAWColors::TrackBackground : 
                            Color(DAWColors::TrackBackground.r * 1.1f,
                                  DAWColors::TrackBackground.g * 1.1f,
                                  DAWColors::TrackBackground.b * 1.1f);
            
            fillRect(contentX, y, contentWidth, height, bgColor);
            
            // Draw track content (regions/waveforms)
            drawTrackContent(rt, *track, y, height);
            
            // Track separator line
            drawLine(0, y + height, static_cast<float>(getWidth()), y + height,
                     DAWColors::GridLine, 1.0f);
        }
        
        y += height;
    }
}

void TimelineView::drawTrackHeader(ID2D1RenderTarget* rt, Track& track, 
                                    float y, float height) {
    // Header background
    fillRect(0, y, TRACK_HEADER_WIDTH, height, DAWColors::TrackHeader);
    
    // Track color indicator
    fillRect(0, y, 4, height, Color(track.getColor()));
    
    // Track name
    drawText(track.getName(), 12, y + 8, DAWColors::TextPrimary, 
             TRACK_HEADER_WIDTH - 20, 20);
    
    // Mute/Solo/Arm buttons
    float btnY = y + height - 28;
    float btnSize = 20;
    float btnSpacing = 4;
    float btnX = 12;
    
    // Mute button
    Color muteColor = track.isMuted() ? Color(0.9f, 0.3f, 0.3f) : DAWColors::ButtonNormal;
    fillRect(btnX, btnY, btnSize, btnSize, muteColor);
    drawText(L"M", btnX + 5, btnY, DAWColors::TextPrimary, btnSize, btnSize);
    btnX += btnSize + btnSpacing;
    
    // Solo button  
    Color soloColor = track.isSolo() ? Color(0.9f, 0.8f, 0.2f) : DAWColors::ButtonNormal;
    fillRect(btnX, btnY, btnSize, btnSize, soloColor);
    drawText(L"S", btnX + 5, btnY, DAWColors::TextPrimary, btnSize, btnSize);
    btnX += btnSize + btnSpacing;
    
    // Arm button
    Color armColor = track.isArmed() ? Color(0.9f, 0.2f, 0.2f) : DAWColors::ButtonNormal;
    fillRect(btnX, btnY, btnSize, btnSize, armColor);
    drawText(L"R", btnX + 5, btnY, DAWColors::TextPrimary, btnSize, btnSize);
    
    // Volume indicator (simple bar)
    float volBarX = TRACK_HEADER_WIDTH - 30;
    float volBarH = height - 40;
    float volBarW = 8;
    float volBarY = y + 30;
    
    fillRect(volBarX, volBarY, volBarW, volBarH, DAWColors::ButtonNormal);
    float volFill = volBarH * track.getVolume();
    fillRect(volBarX, volBarY + volBarH - volFill, volBarW, volFill, 
             Color(0.4f, 0.8f, 0.4f));
    
    // Border
    drawLine(TRACK_HEADER_WIDTH - 1, y, TRACK_HEADER_WIDTH - 1, y + height,
             DAWColors::GridLine, 1.0f);
}

void TimelineView::drawTrackContent(ID2D1RenderTarget* rt, Track& track,
                                     float y, float height) {
    Color trackColor(track.getColor());
    
    for (const auto& region : track.getRegions()) {
        drawWaveform(rt, region, y, height, trackColor);
    }
}

void TimelineView::drawWaveform(ID2D1RenderTarget* rt, const TrackRegion& region,
                                 float trackY, float trackHeight, const Color& color) {
    if (!region.clip) return;
    
    int startX = timeToPixel(region.startTime);
    int endX = timeToPixel(region.startTime + region.duration);
    
    // Clip to visible area
    int visibleStart = std::max(startX, TRACK_HEADER_WIDTH);
    int visibleEnd = std::min(endX, getWidth());
    
    if (visibleEnd <= visibleStart) return;
    
    // Region background
    float regionY = trackY + 4;
    float regionHeight = trackHeight - 8;
    
    fillRect(static_cast<float>(startX), regionY, 
             static_cast<float>(endX - startX), regionHeight,
             Color(color.r * 0.3f, color.g * 0.3f, color.b * 0.3f, 0.8f));
    
    // Region border
    drawRect(static_cast<float>(startX), regionY,
             static_cast<float>(endX - startX), regionHeight,
             color, 1.0f);
    
    // Get waveform data
    int waveformWidth = visibleEnd - visibleStart;
    auto waveform = region.clip->getWaveformData(waveformWidth);
    
    if (waveform.empty()) return;
    
    // Draw waveform
    float centerY = regionY + regionHeight / 2;
    float amplitude = (regionHeight / 2) * 0.9f;
    
    // Calculate offset for visible portion
    double pixelsPerSecond = m_pixelsPerSecond;
    double visibleStartTime = pixelToTime(visibleStart) - region.startTime + region.clipOffset;
    double visibleDuration = (visibleEnd - visibleStart) / pixelsPerSecond;
    
    size_t totalSamples = region.clip->getSampleCount();
    double clipDuration = region.clip->getDuration();
    
    for (int x = 0; x < waveformWidth && x < static_cast<int>(waveform.size()); ++x) {
        auto [minVal, maxVal] = waveform[x];
        
        float y1 = centerY - maxVal * amplitude;
        float y2 = centerY - minVal * amplitude;
        
        drawLine(static_cast<float>(visibleStart + x), y1,
                 static_cast<float>(visibleStart + x), y2,
                 DAWColors::Waveform, 1.0f);
    }
}

void TimelineView::drawPlayhead(ID2D1RenderTarget* rt) {
    int x = timeToPixel(m_playheadPosition);
    
    if (x >= TRACK_HEADER_WIDTH && x <= getWidth()) {
        // Playhead line
        drawLine(static_cast<float>(x), 0, 
                 static_cast<float>(x), static_cast<float>(getHeight()),
                 DAWColors::Playhead, 2.0f);
        
        // Playhead triangle at top
        ID2D1PathGeometry* geometry = nullptr;
        Application::getInstance().getD2DFactory()->CreatePathGeometry(&geometry);
        
        if (geometry) {
            ID2D1GeometrySink* sink = nullptr;
            geometry->Open(&sink);
            
            if (sink) {
                float triSize = 8;
                sink->BeginFigure(D2D1::Point2F(static_cast<float>(x), RULER_HEIGHT),
                                  D2D1_FIGURE_BEGIN_FILLED);
                sink->AddLine(D2D1::Point2F(static_cast<float>(x - triSize), 0));
                sink->AddLine(D2D1::Point2F(static_cast<float>(x + triSize), 0));
                sink->EndFigure(D2D1_FIGURE_END_CLOSED);
                sink->Close();
                sink->Release();
                
                getBrush()->SetColor(DAWColors::Playhead.toD2D());
                rt->FillGeometry(geometry, getBrush());
            }
            geometry->Release();
        }
    }
}

double TimelineView::pixelToTime(int x) const {
    return (x - TRACK_HEADER_WIDTH) / m_pixelsPerSecond + m_scrollX;
}

int TimelineView::timeToPixel(double time) const {
    return static_cast<int>((time - m_scrollX) * m_pixelsPerSecond) + TRACK_HEADER_WIDTH;
}

double TimelineView::snapTime(double time) const {
    if (!m_snapToGrid) return time;
    
    double secondsPerBeat = 60.0 / m_bpm;
    return round(time / secondsPerBeat) * secondsPerBeat;
}

int TimelineView::getTrackAtY(int y) const {
    if (y < RULER_HEIGHT) return -1;
    
    int trackY = RULER_HEIGHT - m_scrollY;
    for (size_t i = 0; i < m_tracks.size(); ++i) {
        int trackHeight = m_tracks[i]->getHeight();
        if (y >= trackY && y < trackY + trackHeight) {
            return static_cast<int>(i);
        }
        trackY += trackHeight;
    }
    return -1;
}

void TimelineView::onResize(int width, int height) {
    invalidate();
}

void TimelineView::onMouseDown(int x, int y, int button) {
    if (button == 0) {
        if (y < RULER_HEIGHT && x >= TRACK_HEADER_WIDTH) {
            // Click on ruler - move playhead
            m_draggingPlayhead = true;
            double time = pixelToTime(x);
            setPlayheadPosition(snapTime(time));
            if (m_onPlayheadChanged) {
                m_onPlayheadChanged(m_playheadPosition);
            }
        }
        else if (x < TRACK_HEADER_WIDTH) {
            // Click on track header
            int track = getTrackAtY(y);
            if (track >= 0) {
                m_selectedTrack = track;
                // TODO: Handle mute/solo/arm button clicks
            }
        }
        else {
            // Click on track content area
            m_selectedTrack = getTrackAtY(y);
        }
    }
    
    m_dragStartX = x;
    m_dragStartY = y;
    invalidate();
}

void TimelineView::onMouseUp(int x, int y, int button) {
    m_draggingPlayhead = false;
    m_draggingRegion = false;
    invalidate();
}

void TimelineView::onMouseMove(int x, int y) {
    if (m_draggingPlayhead) {
        double time = pixelToTime(x);
        setPlayheadPosition(snapTime(time));
        if (m_onPlayheadChanged) {
            m_onPlayheadChanged(m_playheadPosition);
        }
    }
}

void TimelineView::onMouseWheel(int x, int y, int delta) {
    if (GetKeyState(VK_CONTROL) & 0x8000) {
        // Ctrl + wheel = zoom
        double zoomFactor = (delta > 0) ? 1.2 : 0.8;
        double mouseTime = pixelToTime(x);
        
        m_pixelsPerSecond = std::clamp(m_pixelsPerSecond * zoomFactor, 10.0, 1000.0);
        
        // Keep mouse position at same time after zoom
        m_scrollX = mouseTime - (x - TRACK_HEADER_WIDTH) / m_pixelsPerSecond;
        m_scrollX = std::max(0.0, m_scrollX);
    }
    else {
        // Normal wheel = scroll
        if (GetKeyState(VK_SHIFT) & 0x8000) {
            // Horizontal scroll
            m_scrollX -= delta / 120.0 * 50 / m_pixelsPerSecond;
            m_scrollX = std::max(0.0, m_scrollX);
        }
        else {
            // Vertical scroll
            m_scrollY -= delta / 120 * 30;
            m_scrollY = std::max(0, m_scrollY);
        }
    }
    invalidate();
}
