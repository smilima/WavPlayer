#include "Application.h"
#include <Windows.h>

int WINAPI wWinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, 
                    LPWSTR lpCmdLine, int nCmdShow) {
    // Enable high DPI awareness
    SetProcessDPIAware();

    Application& app = Application::getInstance();
    
    if (!app.initialize(hInstance)) {
        return -1;
    }

    int result = app.run();
    
    app.shutdown();
    
    return result;
}
